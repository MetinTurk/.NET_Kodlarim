﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOP_Tekrari.MuzikPlatformu
{
    internal class VeriEklemeHatasi:Exception
    {
        public VeriEklemeHatasi(string message) : base(message)
        {
            
        }
    }
}
