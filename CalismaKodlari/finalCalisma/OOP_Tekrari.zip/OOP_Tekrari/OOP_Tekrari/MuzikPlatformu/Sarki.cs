﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOP_Tekrari.MuzikPlatformu
{
    internal class Sarki :MedyaOgesi<int>
    {
        public string Sanatci { get; set; }
    }
}
