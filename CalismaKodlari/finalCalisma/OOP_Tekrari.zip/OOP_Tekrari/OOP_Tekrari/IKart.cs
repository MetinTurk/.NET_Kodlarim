﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOP_Tekrari
{
    internal interface IKart
    {
        string Sembol { get; set; }
        int Deger { get; set; }
    }
}
