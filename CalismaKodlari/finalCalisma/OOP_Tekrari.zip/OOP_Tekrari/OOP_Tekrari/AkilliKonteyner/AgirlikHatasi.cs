﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOP_Tekrari.AkilliKonteyner
{
    internal class AgirlikHatasi: Exception
    {
        public AgirlikHatasi(string message) : base(message)
        {

        }
    }
}
