﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOP_Tekrari.AkilliKonteyner
{
    internal interface IYuk
    {
        int Agirlik { get; }
    }
}
