﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOP_Tekrari.BilgisayarToplamaSihirbazi
{
    internal class EkranKarti
    {
    }
}
