﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOP_Tekrari.PistiOyunu
{
    internal class Deste
    {
        public List<Kart> kartlar { get; set; }
        public Deste()
        {
            kartlar = new List<Kart>();

        }
    }
}
